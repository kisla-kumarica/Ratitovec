package com.example.ratitovec

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var prefs: SharedPreferences=getPreferences(Context.MODE_PRIVATE);
        counterView=findViewById<TextView>( R.id.CounterView);
        //counterView=findViewById<TextView>( R.id.CounterView);
        counterView.text=prefs.getInt("Count",0).toString();
    }
    lateinit var counterView:TextView;

    fun onPovecajClick(v: View)
    {
        var current: Int;
        current=findViewById<TextView>( R.id.CounterView).text.toString().toInt();
        current++;
        findViewById<TextView>( R.id.CounterView).text=current.toString();
        var prefs: SharedPreferences.Editor=getPreferences(Context.MODE_PRIVATE).edit();
        prefs.putInt("Count",current);
        prefs.apply();
    }
}
